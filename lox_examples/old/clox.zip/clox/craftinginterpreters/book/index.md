This text is not used. All of the content is in the index.html template.
