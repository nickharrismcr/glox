This text is not used. All of the content is in the contents.html template.
