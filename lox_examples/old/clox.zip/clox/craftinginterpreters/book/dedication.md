<div class="dedication">

<img src="image/ginny.png" alt="My beloved dog and her stupid face." />

To Ginny, I miss your stupid face.

</div>